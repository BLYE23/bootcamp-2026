pdf(NULL)  # suppress the default Rplots.pdf device when run via Rscript

source("R/functions.R")
source("scripts/1_clean.R")
source("scripts/2_transform.R")
source("scripts/3_plot.R")
rmarkdown::render("reports/report.Rmd")
